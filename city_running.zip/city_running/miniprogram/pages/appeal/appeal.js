const db = wx.cloud.database();
var app=getApp();
var openid=app.globalData.openid;
Page({

  /**
   * 页面的初始数据
   */
  

  data:{
    appeal_img:'',
    detail:'',
    id:null
  },
  submit(){
    const that = this.data;
    db.collection('order').doc(that.id).update({
      data:{
        appeal_img:that.appeal_img,
        appeal_detail:that.detail,
      }
    }).then(res=>{
      console.log('sucess');
      wx.showModal({
        showCancel:false,
        title:"提示",
        content:"提交成功，客服会尽快处理！",
      })
    }).catch(err=>{
      console.log('fail');
      wx.showModal({
        title: '提示',
        showCancel: false,
        content: '提交失败，请稍后尝试！'
      })
    })
  },

  getCode() {
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        wx.showLoading({
          title: '加载中',
        })
        const random = Math.floor(Math.random() * 1000);
        wx.cloud.uploadFile({
          cloudPath: `expressCode/${random}.png`,
          filePath: res.tempFilePaths[0],
          success: (res) => {
            let fileID = res.fileID;
            this.setData({
              codeImg: fileID,
            })
            wx.hideLoading();
          }
        })
      },
    })
  },

  getExpressCode(e) {
    this.setData({
      detail: e.detail.value,
    })
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options){
    var that=this;
    that.setData({
      id:options.ID,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})