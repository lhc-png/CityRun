// app.js
App({  
  globalData:{
    openid:' '
  },
  onLaunch: function () {
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力');
    } else {
      wx.cloud.init({
        env: 'test-6gk282pu5da0c2a9',
        traceUser: true,
      });
    }
    let that = this;
    wx.cloud.callFunction({
      name:'getData',
      success(res){
        console.log(res.result.openid);
        that.globalData.openid=res.result.openid;
        //console.log(that.globalData.openid)
      }
    })
    //this.globalData = {};
  }
});
