const envList = [{"envId":"xiaoliu-k8902","alias":"xiaoliu"}]
const isMac = false
module.exports = {
    envList,
    isMac
}