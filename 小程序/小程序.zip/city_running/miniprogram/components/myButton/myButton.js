
Component({
  properties: {
      text: {
          type: String,
          value: '确认'
      }
  }
})